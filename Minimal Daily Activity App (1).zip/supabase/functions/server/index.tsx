import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js";

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-c63069a2/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-c63069a2/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: "Missing required fields" }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    
    if (error) {
      console.log(`Signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log(`Error during signup: ${error}`);
    return c.json({ error: "Signup failed" }, 500);
  }
});

// Get user profile
app.get("/make-server-c63069a2/profile/:userId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const userId = c.req.param("userId");
    
    // Ensure user can only access their own profile
    if (user.id !== userId) {
      return c.json({ error: "Forbidden" }, 403);
    }
    
    const profile = await kv.get(`user:${userId}:profile`);
    
    if (!profile) {
      return c.json({ profile: null }, 404);
    }
    
    return c.json({ profile });
  } catch (error) {
    console.log(`Error fetching profile: ${error}`);
    return c.json({ error: "Failed to fetch profile" }, 500);
  }
});

// Save user profile (onboarding)
app.post("/make-server-c63069a2/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const { userId, interest, dailyTime } = await c.req.json();
    
    // Ensure user can only create their own profile
    if (user.id !== userId) {
      return c.json({ error: "Forbidden" }, 403);
    }
    
    if (!userId || !interest || !dailyTime) {
      return c.json({ error: "Missing required fields" }, 400);
    }
    
    const profile = {
      userId,
      interest,
      dailyTime,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`user:${userId}:profile`, profile);
    
    return c.json({ success: true, profile });
  } catch (error) {
    console.log(`Error saving profile: ${error}`);
    return c.json({ error: "Failed to save profile" }, 500);
  }
});

// Get today's activity status
app.get("/make-server-c63069a2/activity/:userId/today", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const userId = c.req.param("userId");
    
    if (user.id !== userId) {
      return c.json({ error: "Forbidden" }, 403);
    }
    
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    
    const activity = await kv.get(`user:${userId}:activity:${today}`);
    
    return c.json({ activity: activity || null });
  } catch (error) {
    console.log(`Error fetching today's activity: ${error}`);
    return c.json({ error: "Failed to fetch activity" }, 500);
  }
});

// Submit activity completion
app.post("/make-server-c63069a2/activity/complete", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const { userId, activityId, answer, difficulty, engagement } = await c.req.json();
    
    if (user.id !== userId) {
      return c.json({ error: "Forbidden" }, 403);
    }
    
    if (!userId || !activityId) {
      return c.json({ error: "Missing required fields" }, 400);
    }
    
    const today = new Date().toISOString().split('T')[0];
    
    const activity = {
      activityId,
      answer,
      difficulty,
      engagement,
      completedAt: new Date().toISOString(),
      date: today,
    };
    
    await kv.set(`user:${userId}:activity:${today}`, activity);
    
    // Update streak
    await updateStreak(userId);
    
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error completing activity: ${error}`);
    return c.json({ error: "Failed to complete activity" }, 500);
  }
});

// Get streak
app.get("/make-server-c63069a2/streak/:userId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user || error) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const userId = c.req.param("userId");
    
    if (user.id !== userId) {
      return c.json({ error: "Forbidden" }, 403);
    }
    
    const streak = await kv.get(`user:${userId}:streak`);
    
    return c.json({ streak: streak || { current: 0, lastDate: null } });
  } catch (error) {
    console.log(`Error fetching streak: ${error}`);
    return c.json({ error: "Failed to fetch streak" }, 500);
  }
});

// Helper function to update streak
async function updateStreak(userId: string) {
  const today = new Date().toISOString().split('T')[0];
  const streak = await kv.get(`user:${userId}:streak`) || { current: 0, lastDate: null };
  
  if (streak.lastDate === today) {
    // Already counted today
    return;
  }
  
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  
  if (streak.lastDate === yesterday) {
    // Continue streak
    streak.current += 1;
  } else if (streak.lastDate === null) {
    // First time
    streak.current = 1;
  } else {
    // Streak broken, restart
    streak.current = 1;
  }
  
  streak.lastDate = today;
  await kv.set(`user:${userId}:streak`, streak);
}

Deno.serve(app.fetch);