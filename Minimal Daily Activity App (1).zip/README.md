
  # Minimal Daily Activity App

  This is a code bundle for Minimal Daily Activity App. The original project is available at https://www.figma.com/design/tY6bYgSJPQHiQQ3PThIah5/Minimal-Daily-Activity-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  