import { createClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "/utils/supabase/info";

const SUPABASE_URL = `https://${projectId}.supabase.co`;

// Create a single Supabase client instance to avoid multiple instances warning
export const supabase = createClient(SUPABASE_URL, publicAnonKey);

export const API_BASE = `${SUPABASE_URL}/functions/v1/make-server-c63069a2`;
