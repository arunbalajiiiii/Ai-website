// Activity content library
export interface ReadingActivity {
  id: string;
  type: 'reading';
  excerpt: string;
  question: string;
  correctAnswer?: string; // Optional for validation
}

export interface PuzzleActivity {
  id: string;
  type: 'puzzles';
  puzzle: string;
  question: string;
}

export interface WritingActivity {
  id: string;
  type: 'writing';
  prompt: string;
  question: string;
}

export type Activity = ReadingActivity | PuzzleActivity | WritingActivity;

// Sample reading activities
const readingActivities: ReadingActivity[] = [
  {
    id: 'read-1',
    type: 'reading',
    excerpt: 'The old lighthouse keeper had watched the sea for forty years. He knew every mood of the water, every shift in the wind. But tonight was different. Tonight, the fog rolled in with an eerie silence that made even the waves seem to hold their breath.',
    question: 'What made tonight different from other nights?'
  },
  {
    id: 'read-2',
    type: 'reading',
    excerpt: 'Maria discovered the journal in her grandmother\'s attic, its leather cover cracked with age. The first entry was dated 1942. As she read, she realized these weren\'t just memories—they were secrets that had shaped her entire family.',
    question: 'Where did Maria find the journal?'
  },
  {
    id: 'read-3',
    type: 'reading',
    excerpt: 'In the quantum realm, particles exist in multiple states simultaneously until observed. This phenomenon, called superposition, challenges our everyday understanding of reality and suggests that observation itself shapes the nature of existence.',
    question: 'What is the term for particles existing in multiple states at once?'
  },
  {
    id: 'read-4',
    type: 'reading',
    excerpt: 'The chef tasted the soup and frowned. Something was missing. Not salt, not pepper—it was the secret ingredient her mentor had taught her years ago. She closed her eyes, trying to remember the small glass jar with the handwritten label.',
    question: 'What did the chef realize was missing from the soup?'
  },
  {
    id: 'read-5',
    type: 'reading',
    excerpt: 'Ancient civilizations used the stars for navigation, agriculture, and timekeeping. The Mayans developed one of the most accurate calendars in history by carefully tracking celestial movements. Their astronomical precision rivaled modern instruments.',
    question: 'What did the Mayans use to create their calendar?'
  }
];

// Sample puzzle activities
const puzzleActivities: PuzzleActivity[] = [
  {
    id: 'puzzle-1',
    type: 'puzzles',
    puzzle: 'I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?',
    question: 'What is your answer to this riddle?'
  },
  {
    id: 'puzzle-2',
    type: 'puzzles',
    puzzle: 'If you have 3 apples and you take away 2, how many do you have?',
    question: 'What is your answer?'
  },
  {
    id: 'puzzle-3',
    type: 'puzzles',
    puzzle: 'A farmer has 17 sheep. All but 9 die. How many are left?',
    question: 'What is your answer?'
  },
  {
    id: 'puzzle-4',
    type: 'puzzles',
    puzzle: 'What can travel around the world while staying in a corner?',
    question: 'What is your answer to this riddle?'
  },
  {
    id: 'puzzle-5',
    type: 'puzzles',
    puzzle: 'The more you take, the more you leave behind. What am I?',
    question: 'What is your answer?'
  }
];

// Sample writing activities
const writingActivities: WritingActivity[] = [
  {
    id: 'write-1',
    type: 'writing',
    prompt: 'Write about a time when you had to choose between what was easy and what was right.',
    question: 'Share your brief response (2-3 sentences)'
  },
  {
    id: 'write-2',
    type: 'writing',
    prompt: 'Describe a place that feels like home to you, using all five senses.',
    question: 'What does this place mean to you?'
  },
  {
    id: 'write-3',
    type: 'writing',
    prompt: 'If you could have dinner with any person from history, who would it be and why?',
    question: 'Write your answer here'
  },
  {
    id: 'write-4',
    type: 'writing',
    prompt: 'Complete this sentence: "The last time I felt truly surprised was when..."',
    question: 'Finish the story'
  },
  {
    id: 'write-5',
    type: 'writing',
    prompt: 'Write a letter to your future self, five years from now.',
    question: 'What would you tell them?'
  }
];

// Get activity by interest
export function getActivityForInterest(interest: string): Activity | null {
  const today = new Date().toISOString().split('T')[0];
  const seed = hashCode(today); // Use date as seed for consistent daily selection
  
  let activities: Activity[] = [];
  
  switch (interest.toLowerCase()) {
    case 'reading':
      activities = readingActivities;
      break;
    case 'puzzles':
      activities = puzzleActivities;
      break;
    case 'writing':
      activities = writingActivities;
      break;
    default:
      return null;
  }
  
  // Select activity based on date seed
  const index = Math.abs(seed) % activities.length;
  return activities[index];
}

// Simple hash function for consistent daily selection
function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return hash;
}
