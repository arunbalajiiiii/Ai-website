import { useState, useEffect } from "react";
import { LandingPage } from "./components/LandingPage";
import { AuthScreen } from "./components/AuthScreen";
import { Onboarding } from "./components/Onboarding";
import { DailyActivity } from "./components/DailyActivity";
import { CompletionScreen } from "./components/CompletionScreen";
import { getActivityForInterest, Activity } from "./lib/activities";
import { supabase, API_BASE } from "./lib/supabase";

type AppState = "loading" | "landing" | "auth" | "onboarding" | "activity" | "completed";

interface UserProfile {
  userId: string;
  interest: string;
  dailyTime: number;
}

export default function App() {
  const [state, setState] = useState<AppState>("loading");
  const [userId, setUserId] = useState<string | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [userName, setUserName] = useState<string>("");
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activity, setActivity] = useState<Activity | null>(null);
  const [streak, setStreak] = useState(0);

  // Check for existing session on mount
  useEffect(() => {
    async function checkSession() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUserId(session.user.id);
          setAccessToken(session.access_token);
          setUserName(session.user.user_metadata?.name || "");
          await loadUserData(session.user.id, session.access_token);
        } else {
          setState("landing");
        }
      } catch (error) {
        console.error("Error checking session:", error);
        setState("landing");
      }
    }

    checkSession();
  }, []);

  const loadUserData = async (uid: string, token: string) => {
    try {
      // Load profile
      const profileRes = await fetch(`${API_BASE}/profile/${uid}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (profileRes.ok) {
        const { profile: userProfile } = await profileRes.json();

        if (userProfile) {
          setProfile(userProfile);

          // Check if today's activity is completed
          const activityRes = await fetch(`${API_BASE}/activity/${uid}/today`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          if (activityRes.ok) {
            const { activity: todayActivity } = await activityRes.json();

            if (todayActivity) {
              // Already completed today
              setState("completed");
            } else {
              // Show today's activity
              const dailyActivity = getActivityForInterest(userProfile.interest);
              setActivity(dailyActivity);
              setState("activity");
            }
          }

          // Load streak
          const streakRes = await fetch(`${API_BASE}/streak/${uid}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          if (streakRes.ok) {
            const { streak: userStreak } = await streakRes.json();
            setStreak(userStreak.current || 0);
          }
        } else {
          // No profile found, show onboarding
          setState("onboarding");
        }
      } else if (profileRes.status === 404) {
        setState("onboarding");
      } else {
        console.error("Failed to load profile");
        setState("onboarding");
      }
    } catch (error) {
      console.error("Error loading user data:", error);
      setState("onboarding");
    }
  };

  const handleAuthSuccess = async (uid: string, token: string) => {
    setUserId(uid);
    setAccessToken(token);
    
    // Get user metadata for name
    const { data: { user } } = await supabase.auth.getUser(token);
    if (user?.user_metadata?.name) {
      setUserName(user.user_metadata.name);
    }
    
    await loadUserData(uid, token);
  };

  const handleOnboardingComplete = async (interest: string, dailyTime: number) => {
    if (!userId || !accessToken) return;

    try {
      const res = await fetch(`${API_BASE}/profile`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          userId,
          interest,
          dailyTime,
        }),
      });

      if (res.ok) {
        const { profile: newProfile } = await res.json();
        setProfile(newProfile);

        // Get today's activity
        const dailyActivity = getActivityForInterest(interest);
        setActivity(dailyActivity);
        setState("activity");
      } else {
        const error = await res.json();
        console.error("Failed to save profile:", error);
      }
    } catch (error) {
      console.error("Error saving profile:", error);
    }
  };

  const handleActivityComplete = async (
    answer: string,
    difficulty: string,
    engagement: string
  ) => {
    if (!activity || !userId || !accessToken) return;

    try {
      const res = await fetch(`${API_BASE}/activity/complete`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          userId,
          activityId: activity.id,
          answer,
          difficulty,
          engagement,
        }),
      });

      if (res.ok) {
        // Reload streak
        const streakRes = await fetch(`${API_BASE}/streak/${userId}`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        if (streakRes.ok) {
          const { streak: userStreak } = await streakRes.json();
          setStreak(userStreak.current || 0);
        }

        setState("completed");
      } else {
        const error = await res.json();
        console.error("Failed to complete activity:", error);
      }
    } catch (error) {
      console.error("Error completing activity:", error);
    }
  };

  const handleReset = () => {
    // For demo purposes - reset to show activity again
    if (profile) {
      const dailyActivity = getActivityForInterest(profile.interest);
      setActivity(dailyActivity);
      setState("activity");
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUserId(null);
    setAccessToken(null);
    setUserName("");
    setProfile(null);
    setActivity(null);
    setStreak(0);
    setState("auth");
  };

  if (state === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-50 to-purple-100">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">DEPREX</h1>
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (state === "landing") {
    return <LandingPage onGetStarted={() => setState("auth")} onSignIn={() => setState("auth")} />;
  }

  if (state === "auth") {
    return <AuthScreen onAuthSuccess={handleAuthSuccess} onBack={() => setState("landing")} />;
  }

  if (state === "onboarding") {
    return <Onboarding onComplete={handleOnboardingComplete} userName={userName} />;
  }

  if (state === "activity" && activity && profile) {
    return (
      <DailyActivity
        activity={activity}
        dailyTime={profile.dailyTime}
        streak={streak}
        onComplete={handleActivityComplete}
        onLogout={handleLogout}
      />
    );
  }

  if (state === "completed") {
    return <CompletionScreen streak={streak} onReset={handleReset} onLogout={handleLogout} />;
  }

  return null;
}