import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { useState } from "react";

interface OnboardingProps {
  onComplete: (interest: string, dailyTime: number) => void;
  userName?: string;
}

export function Onboarding({ onComplete, userName }: OnboardingProps) {
  const [interestType, setInterestType] = useState<string>("");
  const [customInterest, setCustomInterest] = useState<string>("");
  const [dailyTime, setDailyTime] = useState<number>(10);

  const handleSubmit = () => {
    const finalInterest = interestType === "others" ? customInterest : interestType;
    if (finalInterest.trim()) {
      onComplete(finalInterest, dailyTime);
    }
  };

  const isValid = 
    (interestType && interestType !== "others") || 
    (interestType === "others" && customInterest.trim());

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome{userName ? `, ${userName}` : ""}!
          </h1>
          <p className="text-gray-600">
            Let's personalize your daily activity to reduce decision fatigue.
          </p>
        </div>

        <div className="space-y-6">
          {/* Interest Selection */}
          <div>
            <Label className="text-lg font-semibold mb-4 block">
              What interests you?
            </Label>
            <RadioGroup value={interestType} onValueChange={setInterestType}>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="reading" id="reading" />
                  <Label htmlFor="reading" className="cursor-pointer flex-1">
                    📚 Reading
                    <span className="block text-sm text-gray-500 mt-1">
                      Short excerpts with questions
                    </span>
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="puzzles" id="puzzles" />
                  <Label htmlFor="puzzles" className="cursor-pointer flex-1">
                    🧩 Puzzles
                    <span className="block text-sm text-gray-500 mt-1">
                      Brain teasers and riddles
                    </span>
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="writing" id="writing" />
                  <Label htmlFor="writing" className="cursor-pointer flex-1">
                    ✍️ Writing
                    <span className="block text-sm text-gray-500 mt-1">
                      Creative prompts and reflection
                    </span>
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="others" id="others" />
                  <Label htmlFor="others" className="cursor-pointer flex-1">
                    ✨ Others
                    <span className="block text-sm text-gray-500 mt-1">
                      Specify your own interest
                    </span>
                  </Label>
                </div>
              </div>
            </RadioGroup>

            {interestType === "others" && (
              <div className="mt-4">
                <Input
                  value={customInterest}
                  onChange={(e) => setCustomInterest(e.target.value)}
                  placeholder="Type your interest (e.g., coding, meditation, art)"
                  className="w-full"
                />
              </div>
            )}
          </div>

          {/* Time Selection */}
          <div>
            <Label className="text-lg font-semibold mb-4 block">
              Daily time commitment
            </Label>
            <RadioGroup
              value={dailyTime.toString()}
              onValueChange={(val) => setDailyTime(Number(val))}
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="5" id="time-5" />
                  <Label htmlFor="time-5" className="cursor-pointer">
                    5 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="10" id="time-10" />
                  <Label htmlFor="time-10" className="cursor-pointer">
                    10 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="15" id="time-15" />
                  <Label htmlFor="time-15" className="cursor-pointer">
                    15 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="20" id="time-20" />
                  <Label htmlFor="time-20" className="cursor-pointer">
                    20 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="30" id="time-30" />
                  <Label htmlFor="time-30" className="cursor-pointer">
                    30 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                  <RadioGroupItem value="45" id="time-45" />
                  <Label htmlFor="time-45" className="cursor-pointer">
                    45 min
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer col-span-2">
                  <RadioGroupItem value="60" id="time-60" />
                  <Label htmlFor="time-60" className="cursor-pointer">
                    60 min (1 hour)
                  </Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!isValid}
            className="w-full py-6 text-lg"
            size="lg"
          >
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
}
