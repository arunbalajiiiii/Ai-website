import { Button } from "./ui/button";
import { Flame, RefreshCw, LogOut } from "lucide-react";

interface CompletionScreenProps {
  streak: number;
  onReset: () => void;
  onLogout: () => void;
}

export function CompletionScreen({ streak, onReset, onLogout }: CompletionScreenProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-green-50 to-teal-100">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="mb-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🎉</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">All Done!</h1>
          <p className="text-gray-600">
            You've completed today's activity. Come back tomorrow for a new challenge.
          </p>
        </div>

        <div className="bg-gradient-to-r from-orange-100 to-red-100 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Flame className="w-8 h-8 text-orange-500" />
            <span className="text-4xl font-bold text-orange-700">{streak}</span>
          </div>
          <p className="text-gray-700 font-medium">
            {streak === 1 ? "day streak" : "day streak"}
          </p>
          {streak >= 3 && (
            <p className="text-sm text-gray-600 mt-2">
              Keep it up! You're building a great habit.
            </p>
          )}
        </div>

        <div className="text-sm text-gray-500 mb-6">
          <p>See you tomorrow! 👋</p>
        </div>

        {/* Action buttons */}
        <div className="space-y-3">
          <Button
            onClick={onReset}
            variant="outline"
            size="sm"
            className="w-full gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Try Another Activity (Demo)
          </Button>
          
          <Button
            onClick={onLogout}
            variant="ghost"
            size="sm"
            className="w-full gap-2"
          >
            <LogOut className="w-4 h-4" />
            Log Out
          </Button>
        </div>
      </div>
    </div>
  );
}