import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { useState } from "react";
import { Activity } from "../lib/activities";
import { Flame, LogOut } from "lucide-react";

interface DailyActivityProps {
  activity: Activity;
  dailyTime: number;
  streak: number;
  onComplete: (answer: string, difficulty: string, engagement: string) => void;
  onLogout: () => void;
}

export function DailyActivity({
  activity,
  dailyTime,
  streak,
  onComplete,
  onLogout,
}: DailyActivityProps) {
  const [step, setStep] = useState<"activity" | "feedback">("activity");
  const [answer, setAnswer] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [engagement, setEngagement] = useState("");

  const handleActivitySubmit = () => {
    if (answer.trim()) {
      setStep("feedback");
    }
  };

  const handleFeedbackSubmit = () => {
    if (difficulty && engagement) {
      onComplete(answer, difficulty, engagement);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-purple-50 to-pink-100">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        {/* Header with streak */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Today's Activity</h1>
            <p className="text-gray-600 text-sm mt-1">{dailyTime} minutes</p>
          </div>
          <div className="flex items-center gap-2 bg-orange-100 px-4 py-2 rounded-full">
            <Flame className="w-5 h-5 text-orange-500" />
            <span className="font-bold text-orange-700">{streak}</span>
          </div>
        </div>

        {step === "activity" && (
          <div className="space-y-6">
            {/* Activity Content */}
            {activity.type === "reading" && (
              <div className="bg-blue-50 rounded-xl p-6">
                <h2 className="text-sm font-semibold text-blue-900 mb-3 uppercase tracking-wide">
                  Reading
                </h2>
                <p className="text-gray-800 leading-relaxed text-lg">
                  {activity.excerpt}
                </p>
              </div>
            )}

            {activity.type === "puzzles" && (
              <div className="bg-green-50 rounded-xl p-6">
                <h2 className="text-sm font-semibold text-green-900 mb-3 uppercase tracking-wide">
                  Puzzle
                </h2>
                <p className="text-gray-800 text-lg font-medium">
                  {activity.puzzle}
                </p>
              </div>
            )}

            {activity.type === "writing" && (
              <div className="bg-purple-50 rounded-xl p-6">
                <h2 className="text-sm font-semibold text-purple-900 mb-3 uppercase tracking-wide">
                  Writing Prompt
                </h2>
                <p className="text-gray-800 text-lg font-medium">
                  {activity.prompt}
                </p>
              </div>
            )}

            {/* Question */}
            <div className="space-y-3">
              <Label htmlFor="answer" className="text-lg font-semibold">
                {activity.question}
              </Label>
              <Textarea
                id="answer"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Type your answer here..."
                className="min-h-32 text-base resize-none"
                required
              />
            </div>

            <Button
              onClick={handleActivitySubmit}
              disabled={!answer.trim()}
              className="w-full py-6 text-lg"
              size="lg"
            >
              Continue
            </Button>
          </div>
        )}

        {step === "feedback" && (
          <div className="space-y-6">
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 text-center">
              <div className="text-4xl mb-2">✓</div>
              <p className="text-green-900 font-semibold">Activity Complete!</p>
            </div>

            {/* Difficulty */}
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                How difficult was this?
              </Label>
              <RadioGroup value={difficulty} onValueChange={setDifficulty}>
                <div className="flex gap-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="easy" id="diff-easy" />
                      <Label htmlFor="diff-easy" className="cursor-pointer flex-1 text-center">
                        Easy
                      </Label>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="ok" id="diff-ok" />
                      <Label htmlFor="diff-ok" className="cursor-pointer flex-1 text-center">
                        OK
                      </Label>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="hard" id="diff-hard" />
                      <Label htmlFor="diff-hard" className="cursor-pointer flex-1 text-center">
                        Hard
                      </Label>
                    </div>
                  </div>
                </div>
              </RadioGroup>
            </div>

            {/* Engagement */}
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                How engaging was this?
              </Label>
              <RadioGroup value={engagement} onValueChange={setEngagement}>
                <div className="flex gap-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="boring" id="eng-boring" />
                      <Label htmlFor="eng-boring" className="cursor-pointer flex-1 text-center">
                        Boring
                      </Label>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="fine" id="eng-fine" />
                      <Label htmlFor="eng-fine" className="cursor-pointer flex-1 text-center">
                        Fine
                      </Label>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 p-4 rounded-lg border-2 border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer">
                      <RadioGroupItem value="interesting" id="eng-interesting" />
                      <Label htmlFor="eng-interesting" className="cursor-pointer flex-1 text-center">
                        Interesting
                      </Label>
                    </div>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <Button
              onClick={handleFeedbackSubmit}
              disabled={!difficulty || !engagement}
              className="w-full py-6 text-lg"
              size="lg"
            >
              Submit
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}